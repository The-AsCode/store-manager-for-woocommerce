<div id="store-manager-dashboard"></div>

<?php
